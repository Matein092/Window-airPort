package TestAirPort;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import model.*;

class TestA {
	
	private WindowPlane wP;
	private Flight[] f = new Flight[5];
	
	private void setUpScenary1() {
		 wP = new WindowPlane();
		 Flight f1 = new Flight("3:00 AM", "15 04 2019", " AVIANCA   ", "AV098", "Frankfurt", "1", "30-41", "4", " ", "GO TO GATE");
		 Flight f2 = new Flight("6:00 AM", "15 04 2019", "AIR FRANCE", "AF098", "Saint-tropez", "1", "30-41", "25", " ", "GO TO GATE");
		 Flight f3 = new Flight("9:00 AM", "13 04 2019", "       COPA     ", "CP098", "Frankfurt", "1", "30-41", "25", " ", "GO TO GATE");
		 Flight f4 = new Flight("11:00 AM", "14 04 2019", "      KLM       ", "KLM98", "Zagrev", "1", "30-41", "4", " ", "GO TO GATE");
		 Flight f5 = new Flight("3:00 PM", "11 04 2019", "AVIANCA   ", "AV398", "Panama", "1", "30-41", "30", " ", "GO TO GATE");
		 f[0] = f1;
		 f[1] = f2;
		 f[2] = f3;
		 f[3] = f4;
		 f[4] = f5;
		 
		 wP.sortByDate(f);
	}
	@Test
	void testScenary1() {
		setUpScenary1();
		for(int i = 0; i < f.length; i++) {
			for(int j = 0; j < f.length-1;j++) {
			assertTrue("If is in order",f[i].compareByDate(f[j+1]) == 1 );
			}
		}
	}

}
