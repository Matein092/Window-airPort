package model;


public class Flight {
	
	private String time;
	private String airLine;
	private String flight;
	private String destination;
	private String terminal;
	private String checkIn;
	private String gate;
	private String date;
	private String remarks;
	private String expe;
	
	public Flight(String time, String date, String airLine, String flight, String destination, String terminal, String checkIn, String gate, String expe, String remarks){
		this.time = time;
		this.date = date;
		this.airLine = airLine;
		this.flight = flight;
		this.destination = destination;
		this.terminal = terminal;
		this.checkIn = checkIn;
		this.gate = gate;
		this.expe = expe;
		this.remarks = remarks;
		
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getAirLine() {
		return airLine;
	}

	public void setAirLine(String airLine) {
		this.airLine = airLine;
	}

	public String getFlight() {
		return flight;
	}

	public void setFlight(String flight) {
		this.flight = flight;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getTerminal() {
		return terminal;
	}

	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}

	public String getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}

	public String getGate() {
		return gate;
	}

	public void setGate(String gate) {
		this.gate = gate;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getExpe() {
		return expe;
	}

	public void setExpe(String expe) {
		this.expe = expe;
	}
	
	public int compareByTime(Flight f){
    	int numberCompare = time.compareToIgnoreCase(f.getTime());
    	if( numberCompare < 0){
    		numberCompare = -1;
    	}else if(numberCompare == 0){
    		numberCompare = 0;	
    	}else{
    		numberCompare = 1;
    	}
        return numberCompare;
    }
	
	public int compareByDate(Flight f){
    	int numberCompare = date.compareToIgnoreCase(f.getDate());
    	if( numberCompare < 0){
    		numberCompare = -1;
    	}else if(numberCompare == 0){
    		numberCompare = 0;	
    	}else{
    		numberCompare = 1;
    	}
        return numberCompare;
    }
	
	public int compareByAirLine(Flight f){
    	int numberCompare = airLine.compareToIgnoreCase(f.getAirLine());
    	if( numberCompare < 0){
    		numberCompare = -1;
    	}else if(numberCompare == 0){
    		numberCompare = 0;	
    	}else{
    		numberCompare = 1;
    	}
        return numberCompare;
    }
	
	public int compareByFlight(Flight f){
    	int numberCompare = flight.compareToIgnoreCase(f.getFlight());
    	if( numberCompare < 0){
    		numberCompare = -1;
    	}else if(numberCompare == 0){
    		numberCompare = 0;	
    	}else{
    		numberCompare = 1;
    	}
        return numberCompare;
    }
	
	public int compareByDestination(Flight f){
    	int numberCompare = destination.compareToIgnoreCase(f.getDestination());
    	if( numberCompare < 0){
    		numberCompare = -1;
    	}else if(numberCompare == 0){
    		numberCompare = 0;	
    	}else{
    		numberCompare = 1;
    	}
        return numberCompare;
    }
	
	public int compareByTerminal(Flight f){
    	int numberCompare = terminal.compareToIgnoreCase(f.getTerminal());
    	if( numberCompare < 0){
    		numberCompare = -1;
    	}else if(numberCompare == 0){
    		numberCompare = 0;	
    	}else{
    		numberCompare = 1;
    	}
        return numberCompare;
    }
	
	
	public int compareByGate(Flight f){
    	int numberCompare = gate.compareToIgnoreCase(f.getGate());
    	if( numberCompare < 0){
    		numberCompare = -1;
    	}else if(numberCompare == 0){
    		numberCompare = 0;	
    	}else{
    		numberCompare = 1;
    	}
        return numberCompare;
    }
	
	
}
