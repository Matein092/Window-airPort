package model;

import java.util.ArrayList;

public class WindowPlane {

	
	public WindowPlane() {
			
	}
	
	public void sortByDate(Flight[] f) {
		String msg = "";
		for(int i = 0; i < f.length-1; i++) {
			for(int j = 0; j < f.length-1; j++) {
				if(f[j].compareByDate(f[j+1]) == 1){
					Flight aux = f[j];
					f[j] = f[j+1];
					f[j+1] = aux;	
				}
			}
		}
	}
	
	public void sortByTime(Flight[] f) {
		int p, j;
	    Flight aux;
	    for (p = 1; p < f.length; p++){ 
	    	aux = f[p]; 
	        j = p - 1; 
	        while ((j >= 0) && (aux.compareByTime(f[j]) == -1)){                                                              
	        	f[j + 1] = f[j];      
	            j--;                   
	        }
	        f[j + 1] = aux; 
	    }
	}

	public String sortByFlight(Flight[] f) {
		String msg = "";
		for(int i = 0; i < f.length-1; i++) {
			for(int j = 0; j < f.length-1; j++) {
				if(f[j].compareByFlight(f[j+1]) == 1){
					Flight aux = f[j];
					f[j] = f[j+1];
					f[j+1] = aux;					
				}
			}
		}
		return msg;
	}
	
	public void sortByDestination(Flight[] f) {
		int p, j;
	    Flight aux;
	    for (p = 1; p < f.length; p++){ 
	    	aux = f[p]; 
	        j = p - 1; 
	        while ((j >= 0) && (aux.compareByDestination(f[j]) == -1)){                                                              
	        	f[j + 1] = f[j];      
	            j--;                   
	        }
	        f[j + 1] = aux; 
	    }
	}
	
	public void sortByGate(Flight[] f) {
		int p, j;
	    Flight aux;
	    for (p = 1; p < f.length; p++){ 
	    	aux = f[p]; 
	        j = p - 1; 
	        while ((j >= 0) && (aux.compareByGate(f[j]) == -1)){                                                              
	        	f[j + 1] = f[j];      
	            j--;                   
	        }
	        f[j + 1] = aux; 
	    }
	}
}
