package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import model.*;

public class controllerAirPort {
	
	private WindowPlane wP;
	private Flight f1 = new Flight("3:00 AM", "15 04 2019", " AVIANCA   ", "AV098", "Frankfurt", "1", "30-41", "4", " ", "GO TO GATE");
	private Flight f2 = new Flight("6:00 AM", "15 04 2019", "AIR FRANCE", "AF098", "Saint-tropez", "1", "30-41", "25", " ", "GO TO GATE");
	private Flight f3 = new Flight("9:00 AM", "13 04 2019", "       COPA     ", "CP098", "Frankfurt", "1", "30-41", "25", " ", "GO TO GATE");
	private Flight f4 = new Flight("11:00 AM", "14 04 2019", "      KLM       ", "KLM98", "Zagrev", "1", "30-41", "4", " ", "GO TO GATE");
	private Flight f5 = new Flight("3:00 PM", "11 04 2019", "AVIANCA   ", "AV398", "Panama", "1", "30-41", "30", " ", "GO TO GATE");
	private Flight f6 = new Flight("3:00 AM", "13 04 2019", "AVIANCA   ", "AV598", "Venezuela", "1", "30-41", "15", " ", "GO TO GATE");
	private Flight f7 = new Flight("6:00 PM", "14 04 2019", "      COPA    ", "CP123", "Frankfurt", "1", "30-41", "6", " ", "GO TO GATE");
	private Flight f8 = new Flight("4:25 PM", "15 04 2019", "     KLM      ", "KLM641", "Panama", "1", "30-41", "4", " ", "GO TO GATE");
	private Flight f9 = new Flight("11:30 PM", "15 04 2019", "  VIVAIR    ", "VR548", "Frankfurt", "1", "30-41", "30", " ", "GO TO GATE");
	private Flight f10 = new Flight("12:00 PM", "15 04 2019", "   COPA     ", "CP448", "Saint-tropez", "1", "30-41", "3", " ", "GO TO GATE");
	private Flight[] f = {f1,f2,f3,f4,f5,f6,f7,f8,f9,f10};
	
	
	@FXML
	private Label fLabel;
	
	public void orderByDate(ActionEvent event) {
		wP = new WindowPlane();
		String msg = "";
		String msgFinal = "";
		String msg1 = "TIME" + "            " + "DATE" + "            " + "AIRLINE" + "         " + "FLIGHT" + "       " + "DESTINATION" + "       " + "TERMINAL" + "       " + "CHECK IN" + "      "  + "GATE" + "     " + "EXPE" + "       " + "REMARKS" + "\n";
		wP.sortByDate(f);
		for(int j = 0; j < f.length; j++) {
			msg += f[j].getTime() + "       " + f[j].getDate() + "       " + f[j].getAirLine() + "       " + f[j].getFlight() + "            " +
				f[j].getDestination() + "                  " + f[j].getTerminal() + "               " + f[j].getCheckIn() + "              " +  f[j].getGate() + "         " +
				f[j].getExpe() + "                 " + f[j].getRemarks() + "   " + "\n";
		}
		msgFinal = msg1 + msg;
		fLabel.setText(msgFinal);
	}
		
	public void orderByTime(ActionEvent event) {
		wP = new WindowPlane();
		String msg = "";
		String msgFinal = "";
		String msg1 = "TIME" + "            " + "DATE" + "            " + "AIRLINE" + "         " + "FLIGHT" + "       " + "DESTINATION" + "       " + "TERMINAL" + "       " + "CHECK IN" + "      "  + "GATE" + "     " + "EXPE" + "       " + "REMARKS" + "\n";
		wP.sortByTime(f);
		for(int j = 0; j < f.length; j++) {
			msg += f[j].getTime() + "       " + f[j].getDate() + "       " + f[j].getAirLine() + "       " + f[j].getFlight() + "            " +
				f[j].getDestination() + "                  " + f[j].getTerminal() + "               " + f[j].getCheckIn() + "              " +  f[j].getGate() + "         " +
				f[j].getExpe() + "                 " + f[j].getRemarks() + "   " + "\n";
		}
		msgFinal = msg1 + msg;
		fLabel.setText(msgFinal);
	}
	
	public void orderByFlight(ActionEvent event) {
		wP = new WindowPlane();
		String msg = "";
		String msgFinal = "";
		String msg1 = "TIME" + "            " + "DATE" + "            " + "AIRLINE" + "         " + "FLIGHT" + "       " + "DESTINATION" + "       " + "TERMINAL" + "       " + "CHECK IN" + "      "  + "GATE" + "     " + "EXPE" + "       " + "REMARKS" + "\n";
		wP.sortByFlight(f);
		for(int j = 0; j < f.length; j++) {
			msg += f[j].getTime() + "       " + f[j].getDate() + "       " + f[j].getAirLine() + "       " + f[j].getFlight() + "            " +
				f[j].getDestination() + "                  " + f[j].getTerminal() + "               " + f[j].getCheckIn() + "              " +  f[j].getGate() + "         " +
				f[j].getExpe() + "                 " + f[j].getRemarks() + "   " + "\n";
		}
		msgFinal = msg1 + msg;
		fLabel.setText(msgFinal);
	}
	
	public void orderByDestination(ActionEvent event) {
		wP = new WindowPlane();
		String msg = "";
		String msgFinal = "";
		String msg1 = "TIME" + "            " + "DATE" + "            " + "AIRLINE" + "         " + "FLIGHT" + "       " + "DESTINATION" + "       " + "TERMINAL" + "       " + "CHECK IN" + "      "  + "GATE" + "     " + "EXPE" + "       " + "REMARKS" + "\n";
		wP.sortByDestination(f);
		for(int j = 0; j < f.length; j++) {
			msg += f[j].getTime() + "       " + f[j].getDate() + "       " + f[j].getAirLine() + "       " + f[j].getFlight() + "            " +
				f[j].getDestination() + "                  " + f[j].getTerminal() + "               " + f[j].getCheckIn() + "              " +  f[j].getGate() + "         " +
				f[j].getExpe() + "                 " + f[j].getRemarks() + "   " + "\n";
		}
		msgFinal = msg1 + msg;
		fLabel.setText(msgFinal);
	}
	
	public void orderByGate(ActionEvent event) {
		wP = new WindowPlane();
		String msg = "";
		String msgFinal = "";
		String msg1 = "TIME" + "            " + "DATE" + "            " + "AIRLINE" + "         " + "FLIGHT" + "       " + "DESTINATION" + "       " + "TERMINAL" + "       " + "CHECK IN" + "      "  + "GATE" + "     " + "EXPE" + "       " + "REMARKS" + "\n";
		wP.sortByGate(f);
		for(int j = 0; j < f.length; j++) {
			msg += f[j].getTime() + "       " + f[j].getDate() + "       " + f[j].getAirLine() + "       " + f[j].getFlight() + "            " +
				f[j].getDestination() + "                  " + f[j].getTerminal() + "               " + f[j].getCheckIn() + "              " +  f[j].getGate() + "         " +
				f[j].getExpe() + "                 " + f[j].getRemarks() + "   " + "\n";
		}
		msgFinal = msg1 + msg;
		fLabel.setText(msgFinal);
	}
			

}
